self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6940870d6f75fe140ef41ca0c98907b2",
    "url": "/index.html"
  },
  {
    "revision": "6b02344d0a9777aea0f2",
    "url": "/static/css/2.4f1900c2.chunk.css"
  },
  {
    "revision": "1e0b041d65c6cb57f7cf",
    "url": "/static/css/main.3aa74ef0.chunk.css"
  },
  {
    "revision": "6b02344d0a9777aea0f2",
    "url": "/static/js/2.c5f8389e.chunk.js"
  },
  {
    "revision": "391dc31a88845ac6fa3eabcf7e36b59a",
    "url": "/static/js/2.c5f8389e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1e0b041d65c6cb57f7cf",
    "url": "/static/js/main.a2d45aa8.chunk.js"
  },
  {
    "revision": "3d35972054c7d31a4631",
    "url": "/static/js/runtime-main.f4c89bc3.js"
  },
  {
    "revision": "563e3e3446d4cd0ca052dc1727f3eda0",
    "url": "/static/media/icon_-.563e3e34.png"
  },
  {
    "revision": "01e2fe692ad08224d9426d6a3c3af5c6",
    "url": "/static/media/selector.01e2fe69.png"
  }
]);